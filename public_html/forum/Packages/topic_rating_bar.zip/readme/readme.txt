[center][color=red][size=16pt][b]Topic Rating Bar[/b][/size][/color]
[color=blue][b][size=10pt]By Bugo[/size][/b][/color]

[color=green]Simple rating bar for topics.[/color]
Based on [url=http://masugadesign.com/the-lab/scripts/unobtrusive-ajax-star-rating-bar/]Unobtrusive AJAX Star Rating Bar[/url][/center][hr]This work is licensed under the [url=http://opensource.org/licenses/artistic-license-2.0]Artistic License 2.0[/url]